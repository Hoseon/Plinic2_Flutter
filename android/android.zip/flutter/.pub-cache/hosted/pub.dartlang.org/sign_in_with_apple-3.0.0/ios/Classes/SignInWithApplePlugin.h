#import <Flutter/Flutter.h>

@interface SignInWithApplePlugin : NSObject<FlutterPlugin>
@end

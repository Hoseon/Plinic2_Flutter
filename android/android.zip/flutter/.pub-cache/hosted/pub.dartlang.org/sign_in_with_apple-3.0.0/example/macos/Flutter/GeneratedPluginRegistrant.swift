//
//  Generated file. Do not edit.
//

import FlutterMacOS
import Foundation

import sign_in_with_apple

func RegisterGeneratedPlugins(registry: FlutterPluginRegistry) {
  SignInWithApplePlugin.register(with: registry.registrar(forPlugin: "SignInWithApplePlugin"))
}

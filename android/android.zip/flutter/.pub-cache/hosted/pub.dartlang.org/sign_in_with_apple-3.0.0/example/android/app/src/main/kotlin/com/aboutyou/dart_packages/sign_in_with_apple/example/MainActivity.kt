package com.aboutyou.dart_packages.sign_in_with_apple.example

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}

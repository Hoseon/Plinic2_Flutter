#import <Flutter/Flutter.h>

@interface FirebaseAuthOAuthPlugin : NSObject<FlutterPlugin>
@end

#import <Flutter/Flutter.h>

@interface FlutterWebAuthPlugin : NSObject<FlutterPlugin>
@end

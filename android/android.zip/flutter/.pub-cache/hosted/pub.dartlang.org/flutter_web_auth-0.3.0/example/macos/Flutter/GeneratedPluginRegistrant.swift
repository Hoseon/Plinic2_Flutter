//
//  Generated file. Do not edit.
//

import FlutterMacOS
import Foundation

import flutter_web_auth

func RegisterGeneratedPlugins(registry: FlutterPluginRegistry) {
  FlutterWebAuthPlugin.register(with: registry.registrar(forPlugin: "FlutterWebAuthPlugin"))
}

package com.g1p.plinic2

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
